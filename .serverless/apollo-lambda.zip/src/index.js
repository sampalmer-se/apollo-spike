import { ApolloServer } from "apollo-server-lambda";
import { SecretEscapesSchema as schema } from "./schema";

const server = new ApolloServer({ schema });

server.applyMiddleware({ app });

const handler = server.createHandler();

export { handler as graphqlHandler };
